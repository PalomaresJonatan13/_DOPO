package presentation;

import domain.*;
import domain.players.Player;
import domain.DopoHardestGame.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

// ---------------------------------------------------------------------------
// Panel: Game
// ---------------------------------------------------------------------------

class GamePanel extends JPanel {

    private DopoHardestGame game;
    private Timer gameLoop;
    private JLabel statusLabel;
    private JLabel p1StatsLabel;
    private JLabel p2StatsLabel;
    private BoardRenderer renderer;

    public GamePanel() {
        this.prepareElements();
    }

    private void prepareElements() {
        setLayout(new BorderLayout());
        setBackground(new Color(10, 10, 20));

        renderer = new BoardRenderer();
        add(renderer, BorderLayout.CENTER);

        statusLabel = new JLabel("Use arrow keys to move. Press P to pause.", SwingConstants.CENTER);
        statusLabel.setFont(new Font("SansSerif", Font.PLAIN, 13));
        statusLabel.setForeground(new Color(180, 180, 200));
        statusLabel.setBackground(new Color(20, 20, 35));
        statusLabel.setOpaque(true);
        statusLabel.setBorder(BorderFactory.createEmptyBorder(4, 0, 4, 0));
        add(statusLabel, BorderLayout.SOUTH);

        // Stats Panel at North
        JPanel statsPanel = new JPanel(new BorderLayout());
        statsPanel.setOpaque(false);
        statsPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 0, 20));

        p1StatsLabel = new JLabel("");
        p1StatsLabel.setFont(new Font("Arial Black", Font.BOLD, 14));
        p1StatsLabel.setForeground(new Color(255, 100, 100)); // reddish for P1

        p2StatsLabel = new JLabel("");
        p2StatsLabel.setFont(new Font("Arial Black", Font.BOLD, 14));
        p2StatsLabel.setForeground(new Color(100, 150, 255)); // bluish for P2

        statsPanel.add(p1StatsLabel, BorderLayout.WEST);
        statsPanel.add(p2StatsLabel, BorderLayout.EAST);
        add(statsPanel, BorderLayout.NORTH);

        setFocusable(true);
        prepareActions();
    }

    private boolean up, down, left, right;

    private void prepareActions() {
        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (game == null)
                    return;
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_UP -> up = true;
                    case KeyEvent.VK_DOWN -> down = true;
                    case KeyEvent.VK_LEFT -> left = true;
                    case KeyEvent.VK_RIGHT -> right = true;
                    case KeyEvent.VK_P -> game.togglePause();
                }
                updatePlayerMovement();
            }

            public void keyReleased(KeyEvent e) {
                if (game == null)
                    return;
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_UP -> up = false;
                    case KeyEvent.VK_DOWN -> down = false;
                    case KeyEvent.VK_LEFT -> left = false;
                    case KeyEvent.VK_RIGHT -> right = false;
                }
                updatePlayerMovement();
            }
        });
    }

    private void updatePlayerMovement() {
        if (game == null) return;

        int dx = 0, dy = 0;
        if (up)    dy -= 1;
        if (down)  dy += 1;
        if (left)  dx -= 1;
        if (right) dx += 1;

        game.setPlayerDirection(0, dx, dy);
    }

    public void startGame(DopoHardestGame game, Color[] playerColors) {
        this.game = game;
        renderer.setGame(game, playerColors);

        if (gameLoop != null) gameLoop.stop();

        gameLoop = new Timer(20, e -> tick()); // ~50 fps
        gameLoop.start();
    }

    private void tick() {
        if (game == null) return;

        game.update();
        renderer.repaint();
        updateStatsLabels();

        if (game.isVictory()) {
            List<Player> winners = game.getWinners();
            gameLoop.stop();
            if (winners != null && !winners.isEmpty()) {
                if (winners.size() == 1) {
                    statusLabel.setText(String.format("%s wins!", winners.get(0).getName()));
                } else {
                    statusLabel.setText("It's a tie!");
                }
            } else {
                statusLabel.setText("What did just happen?");
            }
        } else if (game.isGameOver()) {
            gameLoop.stop();
            statusLabel.setText("GAME OVER");
        } else if (game.isPaused()) {
            statusLabel.setText("Paused. Press P to resume.");
        } else {
            statusLabel.setText(String.format(
                    "Time: %.2f s              /  Arrow keys to move  /  Press P to pause",
                    game.getTimeRemaining()));
        }
    }

    private void updateStatsLabels() {
        if (game.getPlayers() == null || game.getPlayers().isEmpty()) return;

        List<domain.players.Player> players = game.getPlayers();
        domain.players.Player p1 = players.size() > 0 ? players.get(0) : null;
        domain.players.Player p2 = players.size() > 1 ? players.get(1) : null;

        if (p1 != null) {
            p1StatsLabel.setText(String.format("P1 - Deaths: %d | Coins: %d", p1.getDeaths(), p1.getCoinCount()));
        } else {
            p1StatsLabel.setText("");
        }

        if (p2 != null) {
            String p2Prefix = game.getGameMode() == GameMode.PvsP ? "P2" : "M";
            p2StatsLabel
                    .setText(String.format("%s - Deaths: %d | Coins: %d", p2Prefix, p2.getDeaths(), p2.getCoinCount()));
        } else {
            p2StatsLabel.setText("");
        }
    }
}