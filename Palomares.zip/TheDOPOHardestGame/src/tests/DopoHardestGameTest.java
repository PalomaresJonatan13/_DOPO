package tests;

import domain.*;
import domain.DopoHardestGame.GameMode;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.After;
import org.junit.Before;

import java.util.*;

public class DopoHardestGameTest {
    private DopoHardestGame game;

    /* @Before
    public void setUp() {
        game = new DopoHardestGame();
    } */

    @After
    public void tearDown() {
        game = null;
    }

    public void testInitialState(int expectedWidth, int expectedHeight, GameMode expectedGameMode, double expectedTimeRemaining) {
        assertNotNull(game);

        assertTrue(game.getPlayers().isEmpty());
        assertTrue(game.getEnemies().isEmpty());
        assertTrue(game.getCoins().isEmpty());
        assertTrue(game.getCells().isEmpty());
        assertTrue(game.getSpecialObjects().isEmpty());

        assertFalse(game.isPaused());
        assertFalse(game.isGameOver());
        assertFalse(game.isVictory());
        assertEquals(expectedGameMode, game.getGameMode());
        assertEquals(expectedTimeRemaining, game.getTimeRemaining(), 0.001);
    }

    private void assertGameObjectsState(String expectedState, List<GameObject> gameObjects) {
        assertEquals(expectedState, gameObjects.stream()
            .map((obj) -> obj.toString())
            .reduce((a, b) -> a + ";" + b)
            .orElse("")
        );
    }

    public void assertAllGameObjectsState(DopoHardestGame game, String expectedPlayers, String expectedEnemies, String expectedCoins, String expectedCells, String expectedSpecialObjects) {
        assertGameObjectsState(expectedPlayers, new ArrayList<>(game.getPlayers()));
        assertGameObjectsState(expectedEnemies, new ArrayList<>(game.getEnemies()));
        assertGameObjectsState(expectedCoins, new ArrayList<>(game.getCoins()));
        assertGameObjectsState(expectedCells, new ArrayList<>(game.getCells()));
        assertGameObjectsState(expectedSpecialObjects, new ArrayList<>(game.getSpecialObjects()));
    }

    public void assertGameState(DopoHardestGame game, String expectedPlayers, String expectedEnemies, String expectedCoins, String expectedCells, String expectedSpecialObjects, double expectedTimeRemaining, boolean expectedPaused, boolean expectedGameOver, boolean expectedVictory) {
        assertNotNull(game);
        assertAllGameObjectsState(game, expectedPlayers, expectedEnemies, expectedCoins, expectedCells, expectedSpecialObjects);

        assertEquals(expectedPaused, game.isPaused());
        assertEquals(expectedGameOver, game.isGameOver());
        assertEquals(expectedVictory, game.isVictory());
        assertEquals(expectedTimeRemaining, game.getTimeRemaining(), 0.001);
    }

    // shouldThrowExceptionWhenLoadingNullGameFile
    // shouldThrowExceptionWhenLoadingGameFileWithWrongExtension
    // shouldThrowExceptionWhenLoadingInvalidGameFile
    // shouldLoadValidGameFileCorrectly

    // shouldThrowExceptionWhenLoadingNullMapFile
    // shouldThrowExceptionWhenLoadingMapFileWithWrongExtension
    // shouldThrowExceptionWhenLoadingAMapWithIncorrectNameOfGameObject
    // shouldThrowExceptionWhenLoadingAMapWithIncorrectFormatForTypesOfGameObject
    // shouldThrowExceptionWhenLoadingAMapWithIncorrectNumberOfCoordinatesForGameObject
    // shouldThrowExceptionWhenLoadingAMapWithIncorrectFormatForCoordinatesOfGameObject
    // shouldThrowExceptionWhenLoadingAMapWithIncorrectFormatForDimensionsOfGameObject
    // shouldThrowExceptionWhenLoadingAMapWithIncorrectFormatForTimeRemaining
    // shouldThrowExceptionWhenLoadingAMapIfTheGameModeIsNull
    // shouldThrowExceptionWhenLoadingAMapIfTheGameModeIsNotSupported
    // shouldLoadValidMapFileCorrectly

    // shouldFinishGameIfTheTimeRunsOut
    // shouldFinishGameAndDoNothingTryingToUpdateTheGameAfterTheGameIsOver

    // shouldPauseAndDoNothingTryingToUpdateTheGameWhileTheGameIsPaused
    // shouldAllowToUpdateTheGameAfterPausingAndResumingTheGame
    // shouldAllowToSetPlayerDirectionAfterPausingAndResumingTheGame


    // PLAYER ----------------------------------------
    // shouldNotMoveThePlayerWhileUpdatingTheGameIfByMovingToTheTopItMovesOutOfTheCellsBounds
    // shouldNotMoveThePlayerWhileUpdatingTheGameIfByMovingToTheRightItMovesOutOfTheCellsBounds
    // shouldNotMoveThePlayerWhileUpdatingTheGameIfByMovingToTheBottomItMovesOutOfTheCellsBounds
    // shouldNotMoveThePlayerWhileUpdatingTheGameIfByMovingToTheLeftItMovesOutOfTheCellsBounds

    // shouldMoveThePlayerToTheTopIfThereIsNoCollisionWhileMoving
    // shouldMoveThePlayerToTheRightIfThereIsNoCollisionWhileMoving
    // shouldMoveThePlayerToTheBottomIfThereIsNoCollisionWhileMoving
    // shouldMoveThePlayerToTheLeftIfThereIsNoCollisionWhileMoving

    // shouldHaveABiggerPlayerIfThePlayerIsInBlueState
    // shouldHaveASpeedOf1_5IfThePlayerIsInBlueState
    // shouldHaveASpeedOf2IfThePlayerIsInGreenState

    // shouldResetTheCoinsCollectedByThePlayerWhenThePlayerDies
    // shouldResetThePlayerToTheLastCheckpointWhenThePlayerDies
    // shouldNotResetTheCoinsCollectedByThePlayerWhenThePlayerHasExtraLivesAndDies
    // shouldRemoveAnExtraLifeWhenThePlayerHasExtraLivesAndDies
    // shouldNotResetThePlayerToTheLastCheckpointWhenThePlayerIsInGreenStateAndHasTheShieldAndDies
    // shouldNotResetTheCoinsCollectedWhenThePlayerIsInGreenStateAndHasTheShieldAndDies
    // shouldRemoveTheShieldWhenThePlayerIsInGreenStateAndHasTheShieldAndDies
    // shouldChangeTheSpeedTo0_7IfThePlayerIsInGreenStateAndHasTheShieldAndDies



    // PLAYER - CHECKPOINTS ----------------------------------------
    // shouldUpdateCheckpointWhenPlayerIntersectsAStartCellOrASafeZoneCell
    // shouldNotLetThePlayerDieWhenIntersectingAStartCellOrSafeZoneCell
    // shouldBeVictoryWhenThePlayerIntersectsAFinalCellIfAllCoinsAreCollected
    // shouldNotBeVictoryWhenThePlayerIntersectsAFinalCellIfNotAllCoinsAreCollected



    // PLAYER - COIN COLLISIONS ----------------------------------------
    // shouldCollectCoinWhenPlayerIntersectsAnActiveCoin
    // shouldNotCollectCoinWhenPlayerIntersectsACoinIfTheCoinIsAlreadyCollected
    // shouldChangeStateToGreenWhenPlayerIntersectsAGreenCoin
    // shouldChangeStateToBlueWhenPlayerIntersectsABlueCoin
    // shouldChangeStateToRedWhenPlayerIntersectsARedCoin
    // shouldNotChangeStateWhenPlayerIntersectsANormalCoin
    // shouldNotChangeStateWhenPlayerIntersectsACoinIfTheCoinIsAlreadyCollected
    // shouldDisableTheCoinWhenPlayerIntersectsACoin



    // PLAYER - SPECIAL OBJECT COLLISIONS ----------------------------------------
    // shouldDoNothingWhenPlayerIntersectsASpecialObjectThatIsNotActive
    // shouldAddAnExtraLifeToThePlayerWhenIntersectingALifeSpecialObject
    // shouldKillThePlayerWhenIntersectingAnActiveBombSpecialObject
    // shouldNotKillThePlayerWhenIntersectingAnInactiveBombSpecialObject
    // shouldDisableTheSpecialObjectWhenPlayerIntersectsIt



    // ENEMY ----------------------------------------
    // shouldKillThePlayerWhenAnActiveEnemyIntersectsThePlayer
    // shouldNotKillThePlayerWhenAnInactiveEnemyIntersectsThePlayer
    
    // shouldMoveTheEnemyUpOrDownIfTheEnemyMovesVertically
    // shouldMoveTheEnemyLeftOrRightIfTheEnemyMovesHorizontally
    // shouldHaveSpeed2IfTheEnemyIsFast
    // shouldMoveTheHorizontalEnemyInTheOppositeDirectionIfTheEnemyMovesOutOfTheCellsBounds
    // shouldMoveTheVerticalEnemyInTheOppositeDirectionIfTheEnemyMovesOutOfTheCellsBounds
    // shouldMoveTheEnemyInCirclesIfTheEnemyIsAPatrolEnemy
}
